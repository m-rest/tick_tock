var classSteinberg_1_1IPlugViewContentScaleSupport =
[
    [ "ScaleFactor", "classSteinberg_1_1IPlugViewContentScaleSupport.html#a75ec4b5d086d2af3733ac3775ab008d8", null ],
    [ "setContentScaleFactor", "classSteinberg_1_1IPlugViewContentScaleSupport.html#af5b0fea85beba3cdcfeb8de66779f478", null ]
];
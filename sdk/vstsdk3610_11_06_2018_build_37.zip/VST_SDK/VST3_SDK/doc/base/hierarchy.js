var hierarchy =
[
    [ "ConstStringTable", "classSteinberg_1_1ConstStringTable.html", null ],
    [ "FReleaser", "structSteinberg_1_1FReleaser.html", null ],
    [ "FUID", "classSteinberg_1_1FUID.html", null ],
    [ "FUnknown", "classSteinberg_1_1FUnknown.html", [
      [ "IAttributes", "classSteinberg_1_1IAttributes.html", [
        [ "IAttributes2", "classSteinberg_1_1IAttributes2.html", null ]
      ] ],
      [ "IBStream", "classSteinberg_1_1IBStream.html", null ],
      [ "ICloneable", "classSteinberg_1_1ICloneable.html", null ],
      [ "IDependent", "classSteinberg_1_1IDependent.html", null ],
      [ "IErrorContext", "classSteinberg_1_1IErrorContext.html", null ],
      [ "IPersistent", "classSteinberg_1_1IPersistent.html", null ],
      [ "IPlugFrame", "classSteinberg_1_1IPlugFrame.html", null ],
      [ "IPluginBase", "classSteinberg_1_1IPluginBase.html", null ],
      [ "IPluginFactory", "classSteinberg_1_1IPluginFactory.html", [
        [ "IPluginFactory2", "classSteinberg_1_1IPluginFactory2.html", [
          [ "IPluginFactory3", "classSteinberg_1_1IPluginFactory3.html", null ]
        ] ]
      ] ],
      [ "IPlugView", "classSteinberg_1_1IPlugView.html", null ],
      [ "IPlugViewContentScaleSupport", "classSteinberg_1_1IPlugViewContentScaleSupport.html", null ],
      [ "ISizeableStream", "classSteinberg_1_1ISizeableStream.html", null ],
      [ "IString", "classSteinberg_1_1IString.html", null ],
      [ "IStringResult", "classSteinberg_1_1IStringResult.html", null ],
      [ "IUpdateHandler", "classSteinberg_1_1IUpdateHandler.html", null ],
      [ "IEventHandler", "classSteinberg_1_1Linux_1_1IEventHandler.html", null ],
      [ "IRunLoop", "classSteinberg_1_1Linux_1_1IRunLoop.html", null ],
      [ "ITimerHandler", "classSteinberg_1_1Linux_1_1ITimerHandler.html", null ]
    ] ],
    [ "FVariant", "classSteinberg_1_1FVariant.html", null ],
    [ "IPtr< T >", "classSteinberg_1_1IPtr.html", null ],
    [ "IPtr< I >", "classSteinberg_1_1IPtr.html", [
      [ "FUnknownPtr< I >", "classSteinberg_1_1FUnknownPtr.html", null ],
      [ "OPtr< I >", "classSteinberg_1_1OPtr.html", null ]
    ] ],
    [ "KeyCode", "structSteinberg_1_1KeyCode.html", null ],
    [ "PClassInfo", "structSteinberg_1_1PClassInfo.html", null ],
    [ "PClassInfo2", "structSteinberg_1_1PClassInfo2.html", null ],
    [ "PClassInfoW", "structSteinberg_1_1PClassInfoW.html", null ],
    [ "PFactoryInfo", "structSteinberg_1_1PFactoryInfo.html", null ],
    [ "UString", "classSteinberg_1_1UString.html", [
      [ "UStringBuffer< maxSize >", "classSteinberg_1_1UStringBuffer.html", null ]
    ] ],
    [ "ViewRect", "structSteinberg_1_1ViewRect.html", null ]
];
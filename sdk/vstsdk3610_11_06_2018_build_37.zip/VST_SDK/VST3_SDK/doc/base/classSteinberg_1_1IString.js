var classSteinberg_1_1IString =
[
    [ "setText8", "classSteinberg_1_1IString.html#ac42dc105d9a95ac233eca36746f9afb4", null ],
    [ "setText16", "classSteinberg_1_1IString.html#a855f4116dd9824838ebc984adeccfe96", null ],
    [ "getText8", "classSteinberg_1_1IString.html#a0db45e91ddc50e475381585b7ef8369f", null ],
    [ "getText16", "classSteinberg_1_1IString.html#a292cc4b997e2ff509600bc0339ef8cf3", null ],
    [ "take", "classSteinberg_1_1IString.html#a278b6bc34d672210e69dbde261f52cab", null ],
    [ "isWideString", "classSteinberg_1_1IString.html#a9897ca3a2a9047af3500188209b71ab7", null ]
];
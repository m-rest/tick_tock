var modules =
[
    [ "Basic Interfaces", "group__pluginBase.html", "group__pluginBase" ],
    [ "Graphical User Interface", "group__pluginGUI.html", "group__pluginGUI" ]
];
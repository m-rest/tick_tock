var classSteinberg_1_1IAttributes2 =
[
    [ "countAttributes", "classSteinberg_1_1IAttributes2.html#afab9fceccb1640882d1a4d112b2c5b96", null ],
    [ "getAttributeID", "classSteinberg_1_1IAttributes2.html#a564f166842e13ba6a0bf5111d121c36f", null ]
];
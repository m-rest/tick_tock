var classSteinberg_1_1IPersistent =
[
    [ "getClassID", "classSteinberg_1_1IPersistent.html#aac250bf48a649ebdab843658f7727039", null ],
    [ "saveAttributes", "classSteinberg_1_1IPersistent.html#a67e0bc28988160ead2fae757e4f33900", null ],
    [ "loadAttributes", "classSteinberg_1_1IPersistent.html#a34ba5d29ec54b8d49213549ada3d59fe", null ]
];
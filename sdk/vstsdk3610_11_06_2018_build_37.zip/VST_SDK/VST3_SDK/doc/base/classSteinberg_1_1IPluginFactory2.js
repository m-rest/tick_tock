var classSteinberg_1_1IPluginFactory2 =
[
    [ "getClassInfo2", "classSteinberg_1_1IPluginFactory2.html#af4343086413d489478763677e6925464", null ]
];
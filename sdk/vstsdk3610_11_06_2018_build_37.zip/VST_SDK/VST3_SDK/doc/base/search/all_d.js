var searchData=
[
  ['name',['name',['../structSteinberg_1_1PClassInfo.html#aa9227b03d6c37d746f40c59e671c7af1',1,'Steinberg::PClassInfo::name()'],['../structSteinberg_1_1PClassInfo2.html#aca8ccb4e8b6639590cbe65fc62cb2d91',1,'Steinberg::PClassInfo2::name()'],['../structSteinberg_1_1PClassInfoW.html#a5ff0790e163ec6fb61e6f9f1dcc5d3ed',1,'Steinberg::PClassInfoW::name()']]],
  ['normalizealpha',['NormalizeAlpha',['../namespaceSteinberg.html#a3e48f70b4cb563c93848c357efc48efd',1,'Steinberg']]],
  ['normalizecolorcomponent',['NormalizeColorComponent',['../namespaceSteinberg.html#afd838e124bec32788d0ec8efafe64a7e',1,'Steinberg']]]
];

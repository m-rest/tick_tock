var searchData=
[
  ['graphical_20user_20interface',['Graphical User Interface',['../group__pluginGUI.html',1,'']]]
];

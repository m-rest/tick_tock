var searchData=
[
  ['getfactoryproc',['GetFactoryProc',['../ipluginbase_8h.html#acdf055c3f848689878f8d7cdccac3406',1,'ipluginbase.h']]]
];

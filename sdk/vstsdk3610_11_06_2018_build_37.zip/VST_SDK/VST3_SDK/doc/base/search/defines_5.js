var searchData=
[
  ['implement_5ffunknown_5fmethods',['IMPLEMENT_FUNKNOWN_METHODS',['../funknown_8h.html#a3131ec3273dc17d39bef17154309b893',1,'funknown.h']]],
  ['implement_5fqueryinterface',['IMPLEMENT_QUERYINTERFACE',['../funknown_8h.html#a023a5c16eb6b8a0057d712343f9d752c',1,'funknown.h']]],
  ['implement_5frefcount',['IMPLEMENT_REFCOUNT',['../funknown_8h.html#ae3db5eac4c75b5199dcdc4462b6289aa',1,'funknown.h']]],
  ['inline_5fuid',['INLINE_UID',['../funknown_8h.html#a8024fad3ea7ecdd1ab3221d15e04aa52',1,'funknown.h']]],
  ['inline_5fuid_5ffrom_5ffuid',['INLINE_UID_FROM_FUID',['../funknown_8h.html#ae43645513f5c72529a3fb6c6d1e76b46',1,'funknown.h']]],
  ['inline_5fuid_5fof',['INLINE_UID_OF',['../funknown_8h.html#aaf419cd3f56488ae59cd1b9c8397377b',1,'funknown.h']]]
];

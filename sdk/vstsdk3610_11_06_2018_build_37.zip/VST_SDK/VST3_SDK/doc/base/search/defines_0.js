var searchData=
[
  ['_5funicode',['_UNICODE',['../ftypes_8h.html#a78880e1abcefc90f14185aee93ad0e20',1,'ftypes.h']]]
];

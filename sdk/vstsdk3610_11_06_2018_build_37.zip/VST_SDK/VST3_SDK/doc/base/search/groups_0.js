var searchData=
[
  ['basic_20interfaces',['Basic Interfaces',['../group__pluginBase.html',1,'']]]
];
